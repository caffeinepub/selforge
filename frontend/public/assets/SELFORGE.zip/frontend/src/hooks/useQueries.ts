// This file is intentionally empty as the app uses local state management via Zustand
// No backend queries are needed for this single-user, local-storage-based app
export {};
