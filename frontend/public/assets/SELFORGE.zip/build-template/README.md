## 

To run app build and run docker image: `docker build -t app . docker run -it --network host app`
